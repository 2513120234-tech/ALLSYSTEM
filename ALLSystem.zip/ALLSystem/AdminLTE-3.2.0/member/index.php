<?php
  require_once 'member_auth.php';

  include 'header.php';
  include 'navbar.php';
  include 'sidebar_menu.php';
  include 'main_content.php';
  include 'footer.php';
?>

  

 