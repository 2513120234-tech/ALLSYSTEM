<?php

//start session
session_start();

//Connect database
require_once 'config/condb.php';



//Check username and password from Login form
if (isset($_POST['username'], $_POST['password']) && $_POST['action'] === 'login') {
    //รับค่าจากฟอร์ม
    $username = $_POST['username'];
    $password = $_POST['password'];
    //Query ข้อมูลผู้ใช้จากตาราง users โดยใช้ username ที่รับจากฟอร์ม
    $stmtLogin = $condb->prepare("
        SELECT user_id, password, role 
        FROM users 
        WHERE username = :username
    ");
    $stmtLogin->bindParam(':username', $username, PDO::PARAM_STR);
    $stmtLogin->execute();

    if ($stmtLogin->rowCount() === 1) {

        $row = $stmtLogin->fetch(PDO::FETCH_ASSOC);

        if (password_verify($password, $row['password'])) {
            require_once 'activity_log.php';
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['role']    = $row['role'];

            logActivity($condb, $row['user_id'], $row['role'], 'login');

            if ($_SESSION['role'] === 'admin') {
                header('Location: admin/');
                exit;
            } else if($_SESSION['role'] === 'member') {
                header('Location: member/');
                exit;
            }
            
                
        }else{ 
            require_once 'activity_log.php';

            logActivity($condb, $row['user_id'], $row['role'], 'login_failed');

            echo '<script>
                setTimeout(function() {
                swal({
                    title: "Error!",
                    text: "Username or Password is incorrect.",
                    type: "warning"
                }, function() {
                    window.location = "login.php";
                });
            }, 1000);
            </script>';

        } //else password_verify
    } //if rowCount
} //if isset

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="assets/dist/css/adminlte.min.css">
    <!-- SweetAlert2 -->
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
</head>

<body class="hold-transition login-page">
    <?php
        if (isset($_GET['error']) && $_GET['error'] === 'unauthorized') {
            echo '<script>
                setTimeout(function() {
                swal({
                    title: "You are not authorized!",
                    text: "Please login to continue.",
                    type: "error"
                }, function() {
                    window.location = "login.php";
                });
            }, 1000);
            </script>';
        }
    ?>
<div class="login-box">

  <div class="login-logo">
    <b>Form</b>Login
  </div>

  <!-- ไม่ใช้ card -->
  <div class="login-box-body">
    <p class="login-box-msg">Log in to start your session</p>

    <!-- ✅ form เดิมของคุณ -->
    <form action="" method="post">

      <div class="input-group mb-3">
        <input type="email"
               name="username"
               class="form-control"
               placeholder="Email"
               required>
        <div class="input-group-append">
          <div class="input-group-text">
            <span class="fas fa-envelope"></span>
          </div>
        </div>
      </div>

      <div class="input-group mb-3">
        <input type="password"
               name="password"
               class="form-control"
               placeholder="Password"
               required>
        <div class="input-group-append">
          <div class="input-group-text">
            <span class="fas fa-lock"></span>
          </div>
        </div>
      </div>

      <button type="submit"
              name="action"
              value="login"
              class="btn btn-primary btn-block">
        Log In
      </button>
    </form>

    <div class="social-auth-links text-center mb-3">
        <hr>
        <p>Login Logout Authentication</p>
    </div>
<!-- /.login-card-body -->
 </div>
</div>
<!-- /.login-box -->
</body>

</html>